#-*- coding:utf-8 -*-

LANGUAGES = {
             'العربية': 'ar',
             'English': 'en',
             'Français': 'fr',
             }